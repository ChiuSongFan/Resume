from django.shortcuts import render
from myapp.models import movie

def movie_list(request):
    movies = movie.objects.all()
    return render(request, 'hello_world.html', {'movies': movies})